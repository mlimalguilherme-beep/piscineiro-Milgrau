/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Waves, 
  Sparkles, 
  MapPin, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  PhoneCall, 
  User, 
  Database, 
  TrendingUp, 
  ShieldCheck, 
  Award,
  ChevronDown,
  Droplet,
  ArrowRight,
  Info,
  Layers,
  HelpCircle,
  Upload,
  X,
  Image as ImageIcon
} from "lucide-react";
import ThemeSelector from "./components/ThemeSelector";
import AdminPortal from "./components/AdminPortal";
import LogoMilGrau from "./components/LogoMilGrau";
import { THEME_OPTIONS } from "./types";
import poolBackground from "./assets/images/pool_clean_luxury_1779569003803.png";
import speakerAdriano from "./assets/images/speaker_adriano_1779572127669.png";
import originalFlyer from "./assets/images/original_flyer_1779572809336.png";

export default function App() {
  const [currentTab, setCurrentTab] = useState<"landing" | "admin">("landing");
  
  // Registration Form State
  const [name, setName] = useState("");
  const [city, setCity] = useState("");
  const [preferredDay, setPreferredDay] = useState("Sábado");
  const [preferredTime, setPreferredTime] = useState("Manhã");
  const [selectedThemes, setSelectedThemes] = useState<number[]>([]);
  
  // Handling submission state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [waRedirectUrl, setWaRedirectUrl] = useState("");
  
  // Live registered count
  const [liveCount, setLiveCount] = useState(3); // Default placeholder, fetched on startup
  const [settings, setSettings] = useState<{ googleSheetsUrl?: string; googleSheetsLinked?: boolean; whatsappTemplate?: string; whatsappAutoSend?: boolean; customFlyerBase64?: string; } | null>(null);
  
  // Fetch live count
  const updateLiveCount = async () => {
    try {
      const res = await fetch("/api/registrations");
      if (res.ok) {
        const data = await res.json();
        setLiveCount(data.length);
      }
    } catch (e) {
      console.warn("Utilizando contagem simulada no carregamento inicial.");
    }
  };

  // Fetch settings
  const fetchSettings = async () => {
    try {
      const res = await fetch("/api/admin/settings");
      if (res.ok) {
        const data = await res.json();
        setSettings(data);
      }
    } catch (e) {
      console.warn("Utilizando configurações padrão no carregamento.");
    }
  };

  useEffect(() => {
    updateLiveCount();
    fetchSettings();
    // Scroll smoothly to any hash links
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash === "#cadastro") {
        document.getElementById("form-cadastro")?.scrollIntoView({ behavior: "smooth" });
      } else if (hash === "#sobre") {
        document.getElementById("secao-sobre")?.scrollIntoView({ behavior: "smooth" });
      }
    };
    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, [currentTab]);

  const handleScrollToRegister = () => {
    document.getElementById("form-cadastro")?.scrollIntoView({ behavior: "smooth" });
  };

  const handleFlyerUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64String = reader.result as string;
      try {
        const response = await fetch("/api/admin/settings/upload-flyer", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ base64: base64String })
        });
        if (response.ok) {
          setSettings(prev => prev ? { ...prev, customFlyerBase64: base64String } : { customFlyerBase64: base64String });
        }
      } catch (err) {
        console.error("Erro ao fazer upload da imagem:", err);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveCustomFlyer = async () => {
    try {
      const response = await fetch("/api/admin/settings/upload-flyer", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ base64: "REMOVE" })
      });
      if (response.ok) {
        setSettings(prev => prev ? { ...prev, customFlyerBase64: "" } : null);
      }
    } catch (err) {
      console.error("Erro ao remover imagem:", err);
    }
  };

  const handleFormSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitError("");
    
    // Validations
    if (!name.trim()) {
      setSubmitError("Por favor, informe o seu nome.");
      return;
    }
    if (!city.trim()) {
      setSubmitError("Sua cidade de residência é obrigatória.");
      return;
    }
    if (selectedThemes.length === 0) {
      setSubmitError("Escolha qual tema você tem maior interesse em aprender.");
      return;
    }

    setIsSubmitting(true);

    try {
      const res = await fetch("/api/registrations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          name: name.trim(),
          city: city.trim(),
          preferredDay,
          preferredTime,
          selectedThemes
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Algo deu errado durante o processamento.");
      }

      // Format WhatsApp content message
      // Note: THEME_OPTIONS is imported and available in App.tsx
      const themeId = selectedThemes[0];
      const selectedThemeObj = THEME_OPTIONS.find(t => t.id === themeId);
      const themeTitle = selectedThemeObj ? selectedThemeObj.title : "Não especificado";

      const textMessage = `*Novo Cadastro de Piscineiro - Evento Americana*\n\n` +
                          `👤 *Nome:* ${name.trim()}\n` +
                          `📍 *Cidade:* ${city.trim()}\n` +
                          `📅 *Melhor dia:* ${preferredDay}\n` +
                          `⏰ *Melhor horário:* ${preferredTime}\n` +
                          `💡 *Tema selecionado:* ${themeTitle}\n\n` +
                          `_Enviado pelo site do 1° Evento de Tratadores de Piscina._`;

      const formattedPhone = "5516997588656";
      const waUrl = `https://api.whatsapp.com/send?phone=${formattedPhone}&text=${encodeURIComponent(textMessage)}`;
      setWaRedirectUrl(waUrl);

      // Success
      setSubmitSuccess(true);
      updateLiveCount();
      
      // Clear we loaded form inputs
      setName("");
      setCity("");
      setSelectedThemes([]);

      // Redirect top window to bypass iframe limits
      window.location.href = waUrl;
    } catch (err: any) {
      setSubmitError(err.message || "Não foi possível conectar com o servidor.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-gray-800 font-sans flex flex-col selection:bg-pool-200">
      
      {/* Main View Area */}
      <main className="flex-1 overflow-y-auto bg-grid-pool">
        {currentTab === "landing" ? (
          
          <div className="py-12 max-w-4xl mx-auto px-4 sm:px-6">
            
            {/* 3. FORMULÁRIO DE CADASTRO */}
            <section id="form-cadastro">
              <div className="bg-white rounded-3xl border border-pool-150 p-6 sm:p-10 shadow-lg relative overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-2.5 bg-gradient-to-r from-pool-500 via-mint-500 to-pool-600"></div>

                {submitSuccess ? (
                  // Elegant Success Screen
                  <div className="text-center py-10 space-y-6 animate-fade-in" id="success-screen">
                    <div className="inline-flex items-center justify-center w-20 h-20 bg-emerald-50 rounded-full text-emerald-500 border border-emerald-100 animate-bounce">
                      <CheckCircle2 className="w-12 h-12" />
                    </div>
                    
                    <div className="space-y-3">
                      <h3 className="text-2xl sm:text-3xl font-extrabold font-display text-gray-900">
                        Cadastro enviado com sucesso!
                      </h3>
                      <p className="text-sm text-gray-600 max-w-xl mx-auto leading-relaxed">
                        Obrigado por participar do levantamento do 1° Evento de Tratadores de Piscina de Americana e Região.
                      </p>
                    </div>

                    <div className="p-4.5 bg-emerald-50/50 rounded-2xl border border-emerald-100 max-w-lg mx-auto text-xs text-emerald-800 font-medium space-y-2">
                      <p>● Suas informações já foram salvas em nosso banco de dados regional!</p>
                      <p>● Nosso sistema disparará as orientações do evento diretamente para seu telefone de contato.</p>
                    </div>

                    <div className="pt-4 flex flex-col sm:flex-row gap-3 justify-center items-center">
                      <a
                        href={waRedirectUrl}
                        target="_top"
                        rel="noopener noreferrer"
                        className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 hover:scale-105 active:scale-95 text-white font-extrabold rounded-xl text-sm transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md duration-200 shrink-0"
                      >
                        <svg className="w-4.5 h-4.5 fill-current" viewBox="0 0 24 24">
                          <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.724-1.455L0 24zm6.59-4.846c1.6.95 3.188 1.449 4.725 1.451 5.486.002 9.962-4.438 9.965-9.88.003-2.636-1.019-5.115-2.88-6.973-1.862-1.858-4.341-2.879-6.97-2.88-5.49 0-9.972 4.44-9.975 9.883-.001 2.03.529 4.018 1.535 5.755l-.991 3.616 3.733-.969zM17.13 14.3c-.279-.14-1.65-.81-1.905-.904-.254-.093-.44-.14-.625.14-.185.28-.714.904-.875 1.09-.161.186-.322.21-.601.07-.279-.14-1.18-.435-2.247-1.385-.83-.74-1.39-1.653-1.553-1.933-.163-.28-.018-.43.122-.569.126-.125.279-.327.419-.49.139-.163.185-.28.278-.466.093-.186.046-.35-.023-.49-.07-.14-.625-1.507-.857-2.062-.225-.54-.473-.465-.625-.473-.16-.008-.344-.01-.529-.01-.185 0-.487.07-.74.35-.254.28-.971.95-.971 2.316 0 1.365.993 2.686 1.133 2.873.14.186 1.955 2.986 4.736 4.185.661.286 1.178.455 1.58.583.665.21 1.272.18 1.75.111.533-.078 1.65-.674 1.882-1.325.23-.651.23-1.21.162-1.326-.07-.116-.255-.186-.534-.326z"/>
                        </svg>
                        Enviar p/ WhatsApp
                      </a>
                      <button
                        onClick={() => {
                          setSubmitSuccess(false);
                          setWaRedirectUrl("");
                        }}
                        className="px-5 py-3 bg-pool-50 hover:bg-pool-100 text-pool-700 font-bold rounded-xl text-sm transition-all cursor-pointer"
                      >
                        Nova inscrição
                      </button>
                      <button
                        onClick={() => setCurrentTab("admin")}
                        className="px-5 py-3 bg-pool-800 hover:bg-pool-950 text-white font-bold rounded-xl text-sm transition-all cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        Ver no Painel
                        <Database className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ) : (
                  // The Registration Form
                  <form onSubmit={handleFormSubmit} className="space-y-8">
                    
                    {/* Form Intro */}
                    <div className="space-y-2 border-b border-gray-100 pb-5">
                      <h3 className="text-2xl font-bold font-display text-pool-950 text-center">
                        Formulário de Cadastro
                      </h3>
                    </div>

                    {/* Errors box if any */}
                    {submitError && (
                      <div className="p-4 bg-red-50 border border-red-100 rounded-xl text-red-800 text-xs sm:text-sm font-semibold flex items-center gap-2 animate-pulse">
                        <span className="w-2 h-2 rounded-full bg-red-500"></span>
                        {submitError}
                      </div>
                    )}

                    {/* Input name and city */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5.5">
                      
                      {/* Name field */}
                      <div className="space-y-2">
                        <label htmlFor="input-nome" className="text-xs font-bold text-gray-700 uppercase tracking-wider block">
                          Qual seu nome completo? <span className="text-red-500">*</span>
                        </label>
                        <div className="relative">
                          <User className="absolute left-3.5 top-3.5 text-gray-400 w-5 h-5" />
                          <input
                            type="text"
                            id="input-nome"
                            required
                            placeholder="Ex: Carlos Eduardo de Oliveira"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="w-full pl-11 pr-4 py-3 bg-gray-50 border border-gray-300 rounded-xl focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-pool-500 text-sm font-medium text-gray-900 transition"
                          />
                        </div>
                        <span className="text-[10px] text-gray-400 font-medium block">
                          Como você quer ver escrito em seu certificado de participação.
                        </span>
                      </div>

                      {/* City field */}
                      <div className="space-y-2">
                        <label htmlFor="input-cidade" className="text-xs font-bold text-gray-700 uppercase tracking-wider block">
                          Qual sua cidade de trabalho/residência? <span className="text-red-500">*</span>
                        </label>
                        <div className="relative">
                          <MapPin className="absolute left-3.5 top-3.5 text-gray-400 w-5 h-5" />
                          <input
                            type="text"
                            id="input-cidade"
                            required
                            placeholder="Ex: Americana, Santa Bárbara, Nova Odessa..."
                            value={city}
                            onChange={(e) => setCity(e.target.value)}
                            className="w-full pl-11 pr-4 py-3 bg-gray-50 border border-gray-300 rounded-xl focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-pool-500 text-sm font-medium text-gray-900 transition"
                          />
                        </div>
                        <span className="text-[10px] text-gray-400 font-medium block">
                          Válido para entrega e sorteio de brindes locais.
                        </span>
                      </div>

                    </div>

                    {/* Preferences Selection days / times */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5.5 pt-2">
                      
                      {/* Days picker */}
                      <div className="space-y-2">
                        <label htmlFor="select-preferred-day" className="text-xs font-bold text-gray-700 uppercase tracking-wider block">
                          Qual o melhor dia da semana para participar?
                        </label>
                        <div className="relative">
                          <Calendar className="absolute left-3.5 top-3.5 text-gray-400 w-5 h-5 pointer-events-none" />
                          <select
                            id="select-preferred-day"
                            value={preferredDay}
                            onChange={(e) => setPreferredDay(e.target.value)}
                            className="w-full pl-11 pr-10 py-3 bg-gray-50 border border-gray-350 rounded-xl focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-pool-500 text-sm font-semibold text-gray-800 transition appearance-none cursor-pointer"
                          >
                            <option value="Segunda-feira">Segunda-feira</option>
                            <option value="Terça-feira">Terça-feira</option>
                            <option value="Quarta-feira">Quarta-feira</option>
                            <option value="Quinta-feira">Quinta-feira</option>
                            <option value="Sexta-feira">Sexta-feira</option>
                            <option value="Sábado">Sábado</option>
                            <option value="Domingo">Domingo</option>
                          </select>
                          <ChevronDown className="absolute right-3 top-3.5 text-gray-400 w-5 h-5 pointer-events-none" />
                        </div>
                      </div>

                      {/* Hour picker */}
                      <div className="space-y-2">
                        <label htmlFor="select-preferred-time" className="text-xs font-bold text-gray-700 uppercase tracking-wider block">
                          Qual o melhor horário?
                        </label>
                        <div className="relative">
                          <Clock className="absolute left-3.5 top-3.5 text-gray-400 w-5 h-5 pointer-events-none" />
                          <select
                            id="select-preferred-time"
                            value={preferredTime}
                            onChange={(e) => setPreferredTime(e.target.value)}
                            className="w-full pl-11 pr-10 py-3 bg-gray-50 border border-gray-350 rounded-xl focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-pool-500 text-sm font-semibold text-gray-800 transition appearance-none cursor-pointer"
                          >
                            <option value="Manhã">Manhã (08h00 às 12h00)</option>
                            <option value="Tarde">Tarde (13h30 às 17h30)</option>
                            <option value="Noite">Noite (19h00 às 22h30)</option>
                          </select>
                          <ChevronDown className="absolute right-3 top-3.5 text-gray-400 w-5 h-5 pointer-events-none" />
                        </div>
                      </div>

                    </div>

                    {/* Custom Topics Checkbox Component */}
                    <div className="border-t border-gray-100 pt-6">
                      <ThemeSelector 
                        selectedThemes={selectedThemes} 
                        onChange={setSelectedThemes} 
                      />
                    </div>

                    {/* Final Button */}
                    <div className="border-t border-gray-100 pt-6 flex flex-col items-center space-y-4">
                      
                      <button
                        type="submit"
                        disabled={isSubmitting}
                        id="submit-register-btn"
                        className="w-full py-4.5 bg-gradient-to-r from-pool-600 via-pool-700 to-pool-800 hover:from-pool-700 hover:to-pool-900 text-white font-extrabold text-base rounded-xl transition-all duration-300 transform hover:-translate-y-0.5 shadow-lg shadow-pool-600/20 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75 disabled:cursor-not-allowed"
                      >
                        {isSubmitting ? (
                          <>
                            <span className="w-5 h-5 border-3 border-t-transparent border-white rounded-full animate-spin"></span>
                            <span>Enviando e validando cadastro...</span>
                          </>
                        ) : (
                          <>
                            <span>Enviar Cadastro</span>
                            <ArrowRight className="w-5 h-5" />
                          </>
                        )}
                      </button>

                      
                      {/* Enviar Cadastro Button */}

                    </div>

                  </form>
                )}

              </div>
            </section>

          </div>

        ) : (
          
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
            {/* Embedded Administration Panel */}
            <AdminPortal />
          </div>

        )}
      </main>

      {/* FOOTER */}
      <footer className="bg-slate-900 border-t border-white/10 text-white/55 py-8 text-xs font-medium">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Copyright description */}
          <p className="text-center md:text-left leading-relaxed">
            © 25-26 1° Evento de Tratadores de Piscina de Americana e Região. <br />
            <span className="text-[11px] text-teal-400">
              Evento criado para fortalecer e profissionalizar o mercado de tratadores de piscina.
            </span>
          </p>

          {/* Bottom logos and links */}
          <div className="flex items-center gap-3">
            <span className="text-[10px] bg-white/5 border border-white/10 py-1 px-2.5 rounded font-mono">
              v1.2.0 - Americana SP
            </span>
            <div className="h-4 w-px bg-white/20"></div>
            <button
              onClick={() => setCurrentTab(currentTab === "landing" ? "admin" : "landing")}
              className="hover:text-white transition duration-250 cursor-pointer hover:underline"
            >
              {currentTab === "landing" ? "Área Administrativa" : "Votar Inscrição"}
            </button>
          </div>

        </div>
      </footer>

    </div>
  );
}

