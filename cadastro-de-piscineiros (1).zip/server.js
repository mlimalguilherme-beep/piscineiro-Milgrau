/**
 * Hostinger Universal Node.js Entry Point
 * This file allows Hostinger to automatically detect your Node.js application structure successfully.
 * It automatically directs traffic to the optimized production build when available.
 */

import fs from "fs";
import path from "path";

const ROOT_DIR = process.cwd();
const prodBuildPath = path.join(ROOT_DIR, "dist", "server.cjs");

async function boot() {
  if (fs.existsSync(prodBuildPath)) {
    console.log("[Hostinger Boot] Running compiled production server bundle: dist/server.cjs");
    await import("./dist/server.cjs");
  } else {
    console.log("[Hostinger Boot] Production build not found. Attempting to run typescript source directly...");
    // Register tsx for on-the-fly TS loading in non-production scenarios
    await import("tsx/register");
    await import("./server.ts");
  }
}

boot().catch((err) => {
  console.error("[Hostinger Boot] Error during application startup:", err);
  process.exit(1);
});
