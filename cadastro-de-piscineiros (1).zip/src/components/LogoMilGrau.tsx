import React from "react";

interface LogoMilGrauProps {
  className?: string;
  size?: number;
}

export default function LogoMilGrau({ className = "", size = 48 }: LogoMilGrauProps) {
  return (
    <svg
      viewBox="0 0 540 380"
      width={size}
      height={size * (380 / 540)}
      className={`shrink-0 ${className} select-none`}
      aria-label="Piscineiro Mil Grau Logo"
    >
      <defs>
        {/* Sky / Pool blue gradient for the text filling */}
        <linearGradient id="textGrad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#cffafe" />
          <stop offset="10%" stopColor="#38bdf8" />
          <stop offset="60%" stopColor="#0284c7" />
          <stop offset="100%" stopColor="#0369a1" />
        </linearGradient>

        <linearGradient id="splashGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#38bdf8" />
          <stop offset="100%" stopColor="#0ea5e9" />
        </linearGradient>

        {/* Shadow filter for 3D sticker effect */}
        <filter id="stickerShadow" x="-10%" y="-10%" width="120%" height="120%">
          <feDropShadow dx="0" dy="8" stdDeviation="6" floodColor="#0f172a" floodOpacity="0.18" />
        </filter>
        
        {/* Subtle glow filter */}
        <filter id="waterGlow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="3" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>

      <g filter="url(#stickerShadow)">
        
        {/* ================= WATER SPLASHES (BACKGROUND) ================= */}
        <g id="water-splashes" opacity="0.9">
          {/* Left upper splash */}
          <path 
            d="M 120,150 C 90,135 70,105 85,95 C 100,85 110,115 125,125 C 140,135 130,155 120,150 Z" 
            fill="url(#splashGrad)" 
            filter="url(#waterGlow)"
          />
          <path 
            d="M 100,165 C 75,155 60,135 70,125 C 80,115 90,135 105,145 Z" 
            fill="#e0f2fe" 
          />

          {/* Left middle splash */}
          <path 
            d="M 110,210 C 80,215 55,190 65,180 C 75,170 95,190 115,195 Z" 
            fill="url(#splashGrad)" 
          />
          <path 
            d="M 95,245 C 70,260 55,245 45,235 C 35,225 60,215 80,225 Z" 
            fill="#e0f2fe" 
          />

          {/* Bottom left drops */}
          <circle cx="140" cy="275" r="8" fill="url(#splashGrad)" />
          <circle cx="115" cy="235" r="6" fill="#0ea5e9" />
          <circle cx="95" cy="195" r="5" fill="#38bdf8" />

          {/* Wave splash under the text "Mil" */}
          <path 
            d="M 115,225 C 150,220 180,245 220,230 C 260,215 280,225 310,215 C 330,210 350,230 380,225 C 410,220 440,235 460,225 C 480,215 450,250 400,255 C 350,260 300,240 250,255 C 200,270 150,250 115,225 Z" 
            fill="#0284c7" 
          />
          <path 
            d="M 125,230 C 155,225 185,250 225,235 C 265,220 285,230 315,220 C 335,215 355,235 385,230 C 415,225 435,240 450,230 C 430,245 390,250 340,250 C 290,250 240,260 190,250 C 150,240 135,235 125,230 Z" 
            fill="#38bdf8" 
          />

          {/* Right side splashes */}
          <path 
            d="M 430,170 C 460,165 480,185 470,195 C 460,205 440,190 425,185 Z" 
            fill="url(#splashGrad)" 
          />
          <path 
            d="M 450,150 C 475,145 490,160 485,170 C 480,180 465,170 450,165 Z" 
            fill="#e0f2fe" 
          />
          <circle cx="445" cy="210" r="7" fill="#0ea5e9" />
          <circle cx="465" cy="180" r="5" fill="#38bdf8" />
        </g>

        {/* ================= 3D OUTLINE ENGINE FOR STICKER EFFECT ================= */}
        {/* We stack thick stroke texts to make the rich, cartoon-like double border */}
        
        {/* Border Layer 1: Dark Blue Outer 3D Blocks */}
        <g id="3d-dark-block" opacity="1">
          {/* PISCINEIRO (Thick shadow offset) */}
          <text 
            x="264" y="148" 
            textAnchor="middle" 
            fontFamily="system-ui, -apple-system, sans-serif" 
            fontWeight="bold" 
            fontSize="54" 
            fill="#093d75" 
            stroke="#093d75" 
            strokeWidth="24" 
            strokeLinejoin="round"
            letterSpacing="-1px"
            transform="skewX(-6)"
          >
            Piscineiro
          </text>
          
          {/* MIL GRAU (Thick block offset for 3D look) */}
          {Array.from({ length: 12 }).map((_, i) => (
            <text 
              key={i}
              x={270} y={230 + i * 1.5} 
              textAnchor="middle" 
              fontFamily="system-ui, -apple-system, sans-serif" 
              fontWeight="900" 
              fontSize="106" 
              fill="#093d75" 
              stroke="#093d75" 
              strokeWidth="28" 
              strokeLinejoin="round"
              letterSpacing="-2px"
              transform="skewX(-6)"
            >
              Mil Grau
            </text>
          ))}
        </g>

        {/* Border Layer 2: Middle Vibrant Blue Stroke */}
        <g id="vibrant-blue-border">
          <text 
            x="264" y="145" 
            textAnchor="middle" 
            fontFamily="system-ui, -apple-system, sans-serif" 
            fontWeight="bold" 
            fontSize="54" 
            fill="#0284c7" 
            stroke="#0284c7" 
            strokeWidth="16" 
            strokeLinejoin="round"
            letterSpacing="-1px"
            transform="skewX(-6)"
          >
            Piscineiro
          </text>
          <text 
            x="270" y="230" 
            textAnchor="middle" 
            fontFamily="system-ui, -apple-system, sans-serif" 
            fontWeight="900" 
            fontSize="106" 
            fill="#0284c7" 
            stroke="#0284c7" 
            strokeWidth="20" 
            strokeLinejoin="round"
            letterSpacing="-2px"
            transform="skewX(-6)"
          >
            Mil Grau
          </text>
        </g>

        {/* Border Layer 3: Solid White Outer Wrapper */}
        <g id="white-sticker-border">
          <text 
            x="264" y="145" 
            textAnchor="middle" 
            fontFamily="system-ui, -apple-system, sans-serif" 
            fontWeight="bold" 
            fontSize="54" 
            fill="#ffffff" 
            stroke="#ffffff" 
            strokeWidth="8" 
            strokeLinejoin="round"
            letterSpacing="-1px"
            transform="skewX(-6)"
          >
            Piscineiro
          </text>
          <text 
            x="270" y="230" 
            textAnchor="middle" 
            fontFamily="system-ui, -apple-system, sans-serif" 
            fontWeight="900" 
            fontSize="106" 
            fill="#ffffff" 
            stroke="#ffffff" 
            strokeWidth="12" 
            strokeLinejoin="round"
            letterSpacing="-2px"
            transform="skewX(-6)"
          >
            Mil Grau
          </text>
        </g>

        {/* ================= CORE CONTENT LAYERS (THE FRONT TEXTS) ================= */}
        <g id="front-texts">
          {/* PISCINEIRO (Top curve text - white with light shading) */}
          <text 
            x="264" y="145" 
            textAnchor="middle" 
            fontFamily="system-ui, -apple-system, sans-serif" 
            fontWeight="bold" 
            fontSize="54" 
            fill="#ffffff" 
            letterSpacing="-1px"
            transform="skewX(-6)"
          >
            Piscineiro
          </text>

          {/* MIL GRAU (Center text - styled with luxurious pool-blue gradient) */}
          <text 
            x="270" y="230" 
            textAnchor="middle" 
            fontFamily="system-ui, -apple-system, sans-serif" 
            fontWeight="900" 
            fontSize="106" 
            fill="url(#textGrad)" 
            letterSpacing="-2px"
            transform="skewX(-6)"
          >
            Mil Grau
          </text>
          
          {/* Top gloss white highlight lines over Mil Grau */}
          <text 
            x="270" y="226" 
            textAnchor="middle" 
            fontFamily="system-ui, -apple-system, sans-serif" 
            fontWeight="900" 
            fontSize="106" 
            fill="none" 
            stroke="#ffffff"
            strokeWidth="2"
            letterSpacing="-2px"
            transform="skewX(-6)"
            opacity="0.45"
          >
            Mil Grau
          </text>
        </g>

        {/* ================= VERIFIED BADGE (UPPER RIGHT) ================= */}
        <g id="verified-badge" transform="translate(385, 110) scale(1.1)" filter="url(#stickerShadow)">
          {/* Outer thick border layer of the seal badge */}
          <path 
            d="M 12,0 
               C 17,-3 20,-3 25,0 
               C 30,3 30,6 35,9 
               C 40,12 43,15 42,20 
               C 41,25 38,28 37,33 
               C 36,38 36,41 31,44 
               C 26,47 22,46 17,47 
               C 12,48 8,46 3,44 
               C -2,42 -2,38 -3,33 
               C -4,28 -7,25 -6,20 
               C -5,15 -2,12 3,9 
               C 8,6 8,3 12,0 Z" 
            fill="#ffffff" 
            stroke="#093d75"
            strokeWidth="6"
            strokeLinejoin="round"
          />
          {/* Inner blue seal filling */}
          <path 
            d="M 12,0 
               C 17,-3 20,-3 25,0 
               C 30,3 30,6 35,9 
               C 40,12 43,15 42,20 
               C 41,25 38,28 37,33 
               C 36,38 36,41 31,44 
               C 26,47 22,46 17,47 
               C 12,48 8,46 3,44 
               C -2,42 -2,38 -3,33 
               C -4,28 -7,25 -6,20 
               C -5,15 -2,12 3,9 
               C 8,6 8,3 12,0 Z" 
            fill="#0ea5e9" 
          />
          {/* Ultra clean white heavy Checkmark symbol inside seal */}
          <path 
            d="M 7,20 L 14,27 L 31,11" 
            fill="none" 
            stroke="#ffffff" 
            strokeWidth="6.5" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
          />
        </g>

      </g>
    </svg>
  );
}
