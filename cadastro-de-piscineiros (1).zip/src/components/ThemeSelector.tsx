import { ThemeOption, THEME_OPTIONS } from "../types";
import { Check, Waves, ShieldAlert, BadgeCheck, Settings, Award } from "lucide-react";

interface ThemeSelectorProps {
  selectedThemes: number[];
  onChange: (themes: number[]) => void;
}

export default function ThemeSelector({ selectedThemes, onChange }: ThemeSelectorProps) {

  const handleToggleTheme = (id: number) => {
    if (selectedThemes.includes(id)) {
      onChange([]);
    } else {
      onChange([id]);
    }
  };

  // Helper to categorize topics for a highly professional and organized look in our landing page
  const getThemeCategory = (id: number): { label: string; color: string } => {
    switch(id) {
      case 1:
      case 6:
      case 7:
      case 8:
        return { label: "Química da Água", color: "bg-pool-50 text-pool-700 border-pool-100" };
      case 2:
      case 9:
      case 10:
        return { label: "Soluções de Choque & Tratamento", color: "bg-cyan-50 text-cyan-700 border-cyan-100" };
      case 3:
      case 4:
        return { label: "Rotina & Equipamentos", color: "bg-emerald-50 text-emerald-700 border-emerald-100" };
      case 5:
        return { label: "Gestão & Crescimento Profissional", color: "bg-amber-50 text-amber-700 border-amber-100" };
      default:
        return { label: "Especialidade", color: "bg-gray-50 text-gray-700 border-gray-100" };
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-1">
        <label className="text-sm font-bold text-gray-700 uppercase tracking-wider block">
          Qual tema você tem maior interesse em aprender?
        </label>
        <span className="text-xs text-pool-600 font-bold">
          {selectedThemes.length === 1 ? "1 Selecionado" : "Nenhum Selecionado"}
        </span>
      </div>

      <p className="text-xs text-gray-500 leading-relaxed max-w-2xl">
        Selecione o tema principal que você gostaria que fosse abordado em detalhes pelo palestrante.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4.5">
        {THEME_OPTIONS.map((theme) => {
          const isSelected = selectedThemes.includes(theme.id);
          const category = getThemeCategory(theme.id);

          return (
            <div
              key={theme.id}
              onClick={() => handleToggleTheme(theme.id)}
              id={`theme-card-${theme.id}`}
              className={`group flex items-start gap-3.5 p-4 rounded-xl border transition-all duration-200 cursor-pointer text-left select-none relative ${
                isSelected
                  ? "border-pool-500 bg-pool-50/40 shadow-sm shadow-pool-50"
                  : "border-gray-200 bg-white hover:border-pool-300 hover:bg-pool-50/10 hover:shadow-xs"
              }`}
            >
              {/* Custom styled checkbox indicator */}
              <div 
                className={`w-5 h-5 rounded-md flex items-center justify-center shrink-0 border transition-all mt-1.5 ${
                  isSelected 
                    ? "bg-pool-600 border-pool-600 text-white" 
                    : "border-gray-300 bg-white group-hover:border-pool-400"
                }`}
              >
                {isSelected && <Check className="w-3.5 h-3.5 stroke-[3px]" />}
              </div>

              {/* Text contents */}
              <div className="space-y-2 flex-1">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="font-mono text-[10px] text-gray-400 font-bold">
                    Opção #{theme.id}
                  </span>
                  
                  {/* Category Badge */}
                  <span className={`text-[9px] font-bold px-2 py-0.5 rounded border ${category.color}`}>
                    {category.label}
                  </span>
                </div>

                <div className="space-y-1">
                  <h4 className="font-bold text-gray-900 group-hover:text-pool-850 transition text-sm leading-snug">
                    {theme.title}
                  </h4>
                  <p className="text-xs text-gray-500 font-medium leading-relaxed">
                    {theme.description}
                  </p>
                </div>
              </div>
              
              {/* Highlight bar inside selected themes */}
              {isSelected && (
                <div className="absolute left-0 top-3 bottom-3 w-1 bg-pool-600 rounded-r-lg"></div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
