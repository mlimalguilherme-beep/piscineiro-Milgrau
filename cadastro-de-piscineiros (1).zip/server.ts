import express from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { Registration, AdminSettings } from "./src/types.js";

// Robust file storage and static asset paths using process.cwd()
const ROOT_DIR = process.cwd();

const app = express();
const PORT = 3000;

app.use(express.json());

// Persistent storage file paths
const DB_FILE = path.join(ROOT_DIR, "registrations.json");
const SETTINGS_FILE = path.join(ROOT_DIR, "admin_settings.json");

// Helper to read registrations database safely
function getRegistrations(): Registration[] {
  try {
    if (!fs.existsSync(DB_FILE)) {
      // Create initial sample registrations so the Admin page has realistic, high-quality data upon first load!
      const initialData: Registration[] = [
        {
          id: "reg_1",
          name: "Carlos Eduardo Santos",
          city: "Americana",
          preferredDay: "Sábado",
          preferredTime: "Manhã",
          selectedThemes: [1, 2, 8],
          createdAt: new Date(Date.now() - 3600000 * 4).toISOString()
        },
        {
          id: "reg_2",
          name: "Roberto Oliveira",
          city: "Santa Bárbara d'Oeste",
          preferredDay: "Terça-feira",
          preferredTime: "Noite",
          selectedThemes: [3, 4, 10],
          createdAt: new Date(Date.now() - 3600000 * 24).toISOString()
        },
        {
          id: "reg_3",
          name: "Marina Antunes Silva",
          city: "Nova Odessa",
          preferredDay: "Quinta-feira",
          preferredTime: "Noite",
          selectedThemes: [1, 5, 7],
          createdAt: new Date(Date.now() - 3600000 * 48).toISOString()
        }
      ];
      fs.writeFileSync(DB_FILE, JSON.stringify(initialData, null, 2), "utf8");
      return initialData;
    }
    const content = fs.readFileSync(DB_FILE, "utf8");
    return JSON.parse(content) as Registration[];
  } catch (error) {
    console.error("Erro ao ler banco de dados:", error);
    return [];
  }
}

// Helper to save registrations database safely
function saveRegistrations(data: Registration[]): void {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf8");
  } catch (error) {
    console.error("Erro ao salvar no banco de dados:", error);
  }
}

// Helper to read admin settings
function getSettings(): AdminSettings {
  try {
    if (!fs.existsSync(SETTINGS_FILE)) {
      const defaultSettings: AdminSettings = {
        googleSheetsUrl: "https://docs.google.com/spreadsheets/d/1BxiM_ip6FFXJYgJ5L_B8vH8sW-gJm_w/edit",
        googleSheetsLinked: true,
        whatsappTemplate: "Olá %NOME%, confirmamos seu cadastro no 1° Evento de Tratadores de Piscina! Será no melhor horário indicado por você: %HORARIO% %DIA%. Forte abraço!",
        whatsappAutoSend: true
      };
      fs.writeFileSync(SETTINGS_FILE, JSON.stringify(defaultSettings, null, 2), "utf8");
      return defaultSettings;
    }
    const content = fs.readFileSync(SETTINGS_FILE, "utf8");
    return JSON.parse(content) as AdminSettings;
  } catch (error) {
    console.error("Erro ao ler configurações:", error);
    return {
      googleSheetsUrl: "",
      googleSheetsLinked: false,
      whatsappTemplate: "",
      whatsappAutoSend: false
    };
  }
}

// Helper to save settings
function saveSettings(settings: AdminSettings): void {
  try {
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2), "utf8");
  } catch (error) {
    console.error("Erro ao salvar configurações:", error);
  }
}

// ==================== API ROUTES ====================

// 1. Register a new participant
app.post("/api/registrations", (req, res) => {
  const { name, city, preferredDay, preferredTime, selectedThemes } = req.body;

  // Basic validation
  if (!name || typeof name !== "string" || name.trim().length === 0) {
    return res.status(400).json({ error: "Nome é obrigatório e precisa ser válido." });
  }
  if (!city || typeof city !== "string" || city.trim().length === 0) {
    return res.status(400).json({ error: "Cidade é obrigatória." });
  }
  if (!preferredDay || typeof preferredDay !== "string") {
    return res.status(400).json({ error: "Dia de preferência é obrigatório." });
  }
  if (!preferredTime || typeof preferredTime !== "string") {
    return res.status(400).json({ error: "Horário de preferência é obrigatório." });
  }
  if (!Array.isArray(selectedThemes) || selectedThemes.length === 0) {
    return res.status(400).json({ error: "Selecione ao menos um tema de interesse." });
  }

  const registrations = getRegistrations();
  const newReg: Registration = {
    id: "reg_" + Date.now() + "_" + Math.floor(Math.random() * 1000),
    name: name.trim(),
    city: city.trim(),
    preferredDay,
    preferredTime,
    selectedThemes: selectedThemes.map(Number),
    createdAt: new Date().toISOString()
  };

  registrations.unshift(newReg);
  saveRegistrations(registrations);

  return res.status(201).json({
    success: true,
    message: "Cadastro enviado com sucesso!",
    data: newReg
  });
});

// 2. Fetch all registrations for the admin portal
app.get("/api/registrations", (req, res) => {
  const registrations = getRegistrations();
  return res.json(registrations);
});

// 3. Clear/Reset registrations for administration demonstration
app.post("/api/registrations/reset", (req, res) => {
  fs.unlinkSync(DB_FILE);
  const refreshed = getRegistrations();
  return res.json({ success: true, count: refreshed.length });
});

// 4. Delete specific registration
app.delete("/api/registrations/:id", (req, res) => {
  const idToCancel = req.params.id;
  const registrations = getRegistrations();
  const filtered = registrations.filter((r) => r.id !== idToCancel);
  saveRegistrations(filtered);
  return res.json({ success: true, message: "Cadastro cancelado com sucesso." });
});

// 5. Get admin integration settings
app.get("/api/admin/settings", (req, res) => {
  const settings = getSettings();
  return res.json(settings);
});

// 6. Save admin integration settings
app.post("/api/admin/settings", (req, res) => {
  const settingsInput = req.body as AdminSettings;
  const currentSettings = getSettings();
  const validSettings: AdminSettings = {
    googleSheetsUrl: settingsInput.googleSheetsUrl || "",
    googleSheetsLinked: !!settingsInput.googleSheetsLinked,
    whatsappTemplate: settingsInput.whatsappTemplate || "",
    whatsappAutoSend: !!settingsInput.whatsappAutoSend,
    customFlyerBase64: settingsInput.customFlyerBase64 !== undefined ? settingsInput.customFlyerBase64 : currentSettings.customFlyerBase64
  };
  saveSettings(validSettings);
  return res.json({ success: true, settings: validSettings });
});

// 6.5. Upload custom flyer base64
app.post("/api/admin/settings/upload-flyer", (req, res) => {
  const { base64 } = req.body;
  if (!base64 || typeof base64 !== "string") {
    return res.status(400).json({ error: "Base64 da imagem é obrigatório." });
  }
  const settings = getSettings();
  if (base64 === "REMOVE") {
    settings.customFlyerBase64 = "";
  } else {
    settings.customFlyerBase64 = base64;
  }
  saveSettings(settings);
  return res.json({ success: true, customFlyerBase64: settings.customFlyerBase64 });
});

// 7. Download registration list as CSV (Spreadsheet compatible)
app.get("/api/registrations/export", (req, res) => {
  const registrations = getRegistrations();

  // Generate CSV data in UTF-8 with BOM for correct Excel characters
  let csvContent = "\uFEFF";
  csvContent += "ID;Nome Completo;Cidade;Dia Preferencial;Horário Preferencial;Temas Selecionados;Data de Cadastro\n";

  registrations.forEach((r) => {
    const themesStr = r.selectedThemes.join(", ");
    csvContent += `"${r.id}";"${r.name.replace(/"/g, '""')}";"${r.city.replace(/"/g, '""')}";"${r.preferredDay}";"${r.preferredTime}";"${themesStr}";"${new Date(r.createdAt).toLocaleString("pt-BR")}"\n`;
  });

  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", "attachment; filename=cadastro-piscineiros.csv");
  return res.send(csvContent);
});

// ==================== VITE ENGINE DEVELOPMENT & PRODUCTION HANDLERS ====================

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);

    // Serve index.html for non-API/asset routes in development
    app.get("*", async (req, res, next) => {
      const url = req.originalUrl;
      // Allow API routes to fail naturally if there's no match, or let other middleware handle them
      if (url.startsWith("/api/")) {
        return next();
      }
      try {
        let template = fs.readFileSync(path.join(ROOT_DIR, "index.html"), "utf8");
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ "Content-Type": "text/html" }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    const distPath = path.join(ROOT_DIR, "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Server] Pooling events app running on port ${PORT}`);
    console.log(`[Server] Local URL: http://localhost:${PORT}`);
  });
}

startServer();
