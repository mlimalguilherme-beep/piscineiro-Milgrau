export interface Registration {
  id: string;
  name: string;
  city: string;
  preferredDay: string;
  preferredTime: string;
  selectedThemes: number[]; // numbers from 1 to 10 indicating selected option indices
  createdAt: string; // ISO string
}

export interface WebhookConfig {
  id: string;
  name: string;
  url: string;
  active: boolean;
}

export interface AdminSettings {
  googleSheetsUrl: string;
  googleSheetsLinked: boolean;
  whatsappTemplate: string;
  whatsappAutoSend: boolean;
  adminPasswordHash?: string;
  customFlyerBase64?: string;
}

export interface ThemeOption {
  id: number;
  title: string;
  description: string;
}

export const THEME_OPTIONS: ThemeOption[] = [
  {
    id: 1,
    title: "Tratamento Químico da Água",
    description: "Aprender sobre cloro, pH, alcalinidade, estabilizante e como manter a água cristalina sem desperdício de produto."
  },
  {
    id: 2,
    title: "Como Resolver Água Verde e Turva",
    description: "Passo a passo prático para recuperar piscinas com algas, água leitosa ou manchas."
  },
  {
    id: 3,
    title: "Manutenção Profissional e Rotina do Piscineiro",
    description: "Organização do trabalho, checklist semanal, limpeza correta e técnicas para ganhar produtividade."
  },
  {
    id: 4,
    title: "Equipamentos e Funcionamento da Piscina",
    description: "Como funciona bomba, filtro, casa de máquinas, aspiração e identificação de defeitos comuns."
  },
  {
    id: 5,
    title: "Atendimento ao Cliente e Como Vender Mais Serviços",
    description: "Como fidelizar clientes, aumentar ticket médio, fechar contratos mensais e se destacar como profissional."
  },
  {
    id: 6,
    title: "Como Corrigir pH Alto e pH Baixo",
    description: "Entender como o pH influencia no cloro, conforto da água e eficiência do tratamento."
  },
  {
    id: 7,
    title: "Alcalinidade na Prática",
    description: "O que é alcalinidade, como medir corretamente e como estabilizar a água para evitar variações de pH."
  },
  {
    id: 8,
    title: "Uso Correto do Cloro em Piscinas",
    description: "Diferença entre cloro granulado, líquido e pastilha, dosagens corretas e erros mais comuns."
  },
  {
    id: 9,
    title: "Supercloração e Quebra de Cloramina",
    description: "Quando fazer choque químico, como eliminar cheiro forte de cloro e recuperar a qualidade da água."
  },
  {
    id: 10,
    title: "Estabilizante e Proteção do Cloro",
    description: "Como o estabilizante funciona, quantidade ideal e problemas causados pelo excesso de ácido cianúrico."
  }
];
