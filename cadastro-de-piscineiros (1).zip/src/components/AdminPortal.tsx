import React, { useState, useEffect } from "react";
import { 
  Users, 
  MapPin, 
  Calendar, 
  Clock, 
  BarChart3, 
  FileSpreadsheet, 
  MessageSquare, 
  Trash2, 
  ExternalLink,
  Search, 
  RefreshCw, 
  Download, 
  Check, 
  AlertCircle, 
  Sparkles, 
  Waves,
  ArrowRight,
  Database,
  CheckCircle2,
  Send,
  X,
  Play,
  Upload,
  Image
} from "lucide-react";
import { Registration, AdminSettings, THEME_OPTIONS, ThemeOption } from "../types";

export default function AdminPortal() {
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [settings, setSettings] = useState<AdminSettings>({
    googleSheetsUrl: "",
    googleSheetsLinked: false,
    whatsappTemplate: "",
    whatsappAutoSend: false
  });
  
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCity, setSelectedCity] = useState("Todas");
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [settingsStatusMessage, setSettingsStatusMessage] = useState("");
  const [isSimulatingSheetSync, setIsSimulatingSheetSync] = useState(false);
  
  // Simulated WhatsApp logs
  const [whatsappLogs, setWhatsappLogs] = useState<Array<{id: string; time: string; text: string; status: "Sucesso" | "Pendente"}>>([
    { id: "log_1", time: "Há 10 min", text: "Confirmação enviada para Carlos Eduardo (Americana)", status: "Sucesso" },
    { id: "log_2", time: "Há 1 hora", text: "Confirmação enviada para Roberto Oliveira (S.B.O)", status: "Sucesso" }
  ]);

  // Fetch data from real backend APIs
  const fetchData = async () => {
    setLoading(true);
    try {
      const regRes = await fetch("/api/registrations");
      if (regRes.ok) {
        const regData = await regRes.json();
        setRegistrations(regData);
      }
      
      const settingsRes = await fetch("/api/admin/settings");
      if (settingsRes.ok) {
        const settingsData = await settingsRes.json();
        setSettings(settingsData);
      }
    } catch (e) {
      console.error("Erro ao buscar dados do servidor:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Compute stats
  const totalCount = registrations.length;
  
  // Theme counts
  const themeCounts: { [key: number]: number } = {};
  THEME_OPTIONS.forEach(t => { themeCounts[t.id] = 0; });
  registrations.forEach(r => {
    if (Array.isArray(r.selectedThemes)) {
      r.selectedThemes.forEach(themeId => {
        if (themeCounts[themeId] !== undefined) {
          themeCounts[themeId]++;
        }
      });
    }
  });

  const sortedThemesByInterest = [...THEME_OPTIONS].sort((a, b) => {
    return (themeCounts[b.id] || 0) - (themeCounts[a.id] || 0);
  });

  // Cities count
  const cityCounts: { [key: string]: number } = {};
  registrations.forEach(r => {
    const city = r.city.trim() || "Não Especificada";
    cityCounts[city] = (cityCounts[city] || 0) + 1;
  });
  const uniqueCities = ["Todas", ...Object.keys(cityCounts)];

  // Preferred days count
  const dayCounts: { [key: string]: number } = {};
  registrations.forEach(r => {
    dayCounts[r.preferredDay] = (dayCounts[r.preferredDay] || 0) + 1;
  });

  // Preferred times count
  const timeCounts: { [key: string]: number } = {};
  registrations.forEach(r => {
    timeCounts[r.preferredTime] = (timeCounts[r.preferredTime] || 0) + 1;
  });

  // Delete registration
  const handleDeleteRegistration = async (id: string, name: string) => {
    if (!confirm(`Deseja realmente cancelar o cadastro de "${name}"?`)) return;
    
    try {
      const res = await fetch(`/api/registrations/${id}`, { method: "DELETE" });
      if (res.ok) {
        setRegistrations(prev => prev.filter(r => r.id !== id));
        // Add log
        addWhatsappLog(`Cadastro de ${name} cancelado do painel administrador.`);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Add simulated log
  const addWhatsappLog = (text: string) => {
    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`;
    setWhatsappLogs(prev => [
      { id: "log_" + Date.now(), time: `Hoje às ${timeStr}`, text, status: "Sucesso" },
      ...prev
    ]);
  };

  // Save Settings
  const handleSaveSettings = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSavingSettings(true);
    setSettingsStatusMessage("");
    try {
      const res = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings)
      });
      if (res.ok) {
        setSettingsStatusMessage("Configurações salvas com sucesso!");
        setTimeout(() => setSettingsStatusMessage(""), 4000);
      } else {
        setSettingsStatusMessage("Erro ao salvar no servidor.");
      }
    } catch (error) {
      setSettingsStatusMessage("Erro de rede.");
    } finally {
      setIsSavingSettings(false);
    }
  };

  const handleFlyerUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      setSettings(prev => ({ ...prev, customFlyerBase64: base64String }));
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveFlyer = () => {
    setSettings(prev => ({ ...prev, customFlyerBase64: "" }));
  };

  // Simulated live WhatsApp Trigger
  const handleManualWhatsAppSend = (reg: Registration) => {
    // Generate text replacing placeholders %NOME%, %DIA%, %HORARIO%
    let message = settings.whatsappTemplate;
    message = message.replace(/%NOME%/g, reg.name);
    message = message.replace(/%DIA%/g, reg.preferredDay);
    message = message.replace(/%HORARIO%/g, reg.preferredTime);

    // Encode text for web whatsapp
    const encodedText = encodeURIComponent(message);
    const whatsappUrl = `https://api.whatsapp.com/send?text=${encodedText}`;
    
    // Log as successfully processed
    addWhatsappLog(`Confirmação manual em disparador de WhatsApp para ${reg.name}`);
    
    // Open in separate tab
    window.open(whatsappUrl, "_blank", "noopener,noreferrer");
  };

  // Simulated Google Sheets Refresh Trigger
  const handleSheetSyncSimulation = () => {
    if (!settings.googleSheetsLinked || !settings.googleSheetsUrl) {
      alert("Por favor, ative a integração do Google Sheets com uma URL de planilha válida primeiro!");
      return;
    }
    
    setIsSimulatingSheetSync(true);
    setTimeout(() => {
      setIsSimulatingSheetSync(false);
      addWhatsappLog(`Sincronização forçada: ${registrations.length} cadastros exportados com sucesso para a planilha modelo Google Sheets.`);
      alert("Planilha atualizada com sucesso! Todos os dados de piscineiros foram sincronizados com a planilha de Americana e Região.");
    }, 1500);
  };

  // Filter logic
  const filteredRegistrations = registrations.filter(r => {
    const matchesSearch = r.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          r.city.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCity = selectedCity === "Todas" || r.city === selectedCity;
    return matchesSearch && matchesCity;
  });

  return (
    <div className="space-y-8" id="admin-dashboard">
      
      {/* Header and Controls */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-white p-6 rounded-2xl shadow-sm border border-pool-100">
        <div>
          <div className="flex items-center gap-2 text-pool-700 font-semibold mb-1">
            <span className="p-1.5 bg-pool-50 rounded-lg text-pool-600 block">
              <Database className="w-5 h-5 animate-pulse" />
            </span>
            <span>Painel do Administrador v1.2</span>
          </div>
          <h2 className="text-2xl font-bold font-display text-pool-950">
            Controle de Cadastros e Integrações
          </h2>
          <p className="text-sm text-gray-500">
            Gerencie participantes, analise dados do evento de Americana e automatize notificações.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={fetchData}
            title="Atualizar dados"
            className="flex items-center gap-2 px-4 py-2 bg-pool-50 hover:bg-pool-100 text-pool-700 text-sm font-semibold rounded-lg transition-all duration-200 border border-pool-200"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
            Atualizar
          </button>
          
          <a
            href="/api/registrations/export"
            download
            className="flex items-center gap-2 px-4 py-2 bg-mint-500 hover:bg-mint-600 text-white text-sm font-semibold rounded-lg transition-all duration-200 shadow-sm shadow-mint-100"
          >
            <Download className="w-4 h-4" />
            Exportar CSV Excel
          </a>
        </div>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total cadastros */}
        <div className="p-5 bg-white rounded-2xl border border-pool-100 shadow-xs flex items-center gap-4">
          <div className="p-3.5 bg-pool-50 text-pool-600 rounded-xl">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-semibold text-gray-400 block uppercase tracking-wider">Total Inscritos</span>
            <span className="text-2xl font-bold text-gray-900 font-display">{totalCount}</span>
            <span className="text-[11px] text-mint-600 font-medium block">
              ● Banco de Dados Ativo
            </span>
          </div>
        </div>

        {/* Top Topic */}
        <div className="p-5 bg-white rounded-2xl border border-pool-100 shadow-xs flex items-center gap-4">
          <div className="p-3.5 bg-cyan-50 text-cyan-600 rounded-xl">
            <Waves className="w-6 h-6" />
          </div>
          <div className="flex-1 min-w-0">
            <span className="text-xs font-semibold text-gray-400 block uppercase tracking-wider">Assunto Mais Procurado</span>
            <span className="text-sm font-bold text-gray-900 block truncate font-sans">
              {sortedThemesByInterest[0] ? sortedThemesByInterest[0].title : "Nenhum"}
            </span>
            <span className="text-xs text-pool-600 font-medium ml-0.5">
              {sortedThemesByInterest[0] ? `${themeCounts[sortedThemesByInterest[0].id] || 0} interessados` : "Sem dados"}
            </span>
          </div>
        </div>

        {/* Cidades Unicas */}
        <div className="p-5 bg-white rounded-2xl border border-pool-100 shadow-xs flex items-center gap-4">
          <div className="p-3.5 bg-emerald-50 text-emerald-600 rounded-xl">
            <MapPin className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-semibold text-gray-400 block uppercase tracking-wider">Cidades Atendidas</span>
            <span className="text-2xl font-bold text-gray-900 font-display">{Object.keys(cityCounts).length}</span>
            <span className="text-xs text-emerald-600 font-medium block truncate max-w-[130px]">
              Região de Americana
            </span>
          </div>
        </div>

        {/* Google Sheets status */}
        <div className="p-5 bg-white rounded-2xl border border-pool-100 shadow-xs flex items-center gap-4">
          <div className="p-3.5 bg-green-50 text-green-700 rounded-xl">
            <FileSpreadsheet className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-semibold text-gray-400 block uppercase tracking-wider">Google Planilhas</span>
            <span className="text-sm font-bold text-gray-900 flex items-center gap-1.5 font-sans">
              {settings.googleSheetsLinked ? (
                <>
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  Conectado
                </>
              ) : (
                <>
                  <span className="w-2 h-2 rounded-full bg-gray-400"></span>
                  Inativo
                </>
              )}
            </span>
            <button 
              onClick={handleSheetSyncSimulation}
              disabled={isSimulatingSheetSync || !settings.googleSheetsLinked}
              className="text-[11px] text-pool-600 hover:text-pool-800 disabled:text-gray-400 font-semibold cursor-pointer block mt-1 hover:underline transition"
            >
              {isSimulatingSheetSync ? "Sincronizando..." : "Sincronizar Planilha"}
            </button>
          </div>
        </div>
      </div>

      {/* Main Admin Section Layout (Split into table of registrations and configurations) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Side: Registrations Table (7 cols) */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white rounded-2xl border border-pool-100 shadow-xs overflow-hidden">
            
            {/* Table Header Filter controls */}
            <div className="p-5 bg-pool-50/50 border-b border-pool-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <h3 className="font-bold text-pool-950 flex items-center gap-2 text-lg font-display">
                <Users className="w-5 h-5 text-pool-600" />
                Registros de Participantes ({filteredRegistrations.length})
              </h3>
              
              <div className="flex flex-wrap items-center gap-2">
                {/* Search */}
                <div className="relative">
                  <Search className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Buscar nome ou cidade..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9 pr-3 py-1.5 text-xs bg-white border border-pool-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-pool-500 w-full sm:w-44 transition-all"
                  />
                </div>
                
                {/* City select */}
                <select
                  value={selectedCity}
                  onChange={(e) => setSelectedCity(e.target.value)}
                  className="bg-white border border-pool-200 rounded-lg text-xs py-1.5 px-2.5 focus:outline-hidden focus:ring-1 focus:ring-pool-500 text-pool-900 font-medium"
                >
                  {uniqueCities.map(city => (
                    <option key={city} value={city}>{city}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Table Content */}
            <div className="overflow-x-auto">
              {loading ? (
                <div className="flex flex-col items-center justify-center p-12 text-center text-gray-400 font-medium space-y-3">
                  <RefreshCw className="w-8 h-8 animate-spin text-pool-500" />
                  <p className="text-sm">Buscando banco de valores...</p>
                </div>
              ) : filteredRegistrations.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-12 text-center text-gray-400 bg-gray-50/30">
                  <AlertCircle className="w-10 h-10 text-gray-300 mb-2" />
                  <p className="font-semibold text-pool-950 font-display">Nenhum participante encontrado</p>
                  <p className="text-xs text-gray-400 mt-1">
                    {searchQuery || selectedCity !== "Todas" 
                      ? "Experimente mudar os filtros ou limpar a pesquisa." 
                      : "Cadastre seu primeiro participante na página principal!"}
                  </p>
                </div>
              ) : (
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-gray-50/70 border-b border-pool-100 text-gray-400 font-semibold tracking-wider uppercase text-[10px]">
                      <th className="p-4">Piscineiro</th>
                      <th className="p-4">Localização & Preferência</th>
                      <th className="p-4">Temas Interesse</th>
                      <th className="p-4 text-center">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-pool-50">
                    {filteredRegistrations.map((reg) => (
                      <tr key={reg.id} className="hover:bg-pool-50/30 transition-colors duration-150">
                        
                        {/* Name and registered Date */}
                        <td className="p-4">
                          <div className="font-semibold text-gray-900 text-sm font-sans">{reg.name}</div>
                          <div className="text-[10px] text-gray-400 font-mono mt-0.5 flex items-center gap-1">
                            <Clock className="w-3 h-3 text-gray-300" />
                            {new Date(reg.createdAt).toLocaleString("pt-BR", {
                              day: "2-digit",
                              month: "2-digit",
                              hour: "2-digit",
                              minute: "2-digit"
                            })}
                          </div>
                        </td>

                        {/* Location and preferences */}
                        <td className="p-4 space-y-1">
                          <div className="flex items-center gap-1.5 text-gray-600 font-medium">
                            <MapPin className="w-3.5 h-3.5 text-pool-500 shrink-0" />
                            <span>{reg.city}</span>
                          </div>
                          <div className="flex flex-wrap items-center gap-1">
                            <span className="inline-flex items-center gap-1 bg-pool-50 text-pool-700 text-[10px] px-1.5 py-0.5 rounded font-medium border border-pool-100">
                              <Calendar className="w-3 h-3" />
                              {reg.preferredDay}
                            </span>
                            <span className="inline-flex items-center gap-1 bg-cyan-50 text-cyan-700 text-[10px] px-1.5 py-0.5 rounded font-medium border border-cyan-100">
                              <Clock className="w-3 h-3" />
                              {reg.preferredTime}
                            </span>
                          </div>
                        </td>

                        {/* Selected themes tags */}
                        <td className="p-4">
                          <div className="flex flex-wrap gap-1 max-w-[280px]">
                            {reg.selectedThemes && reg.selectedThemes.map(themeId => {
                              const matchingTheme = THEME_OPTIONS.find(t => t.id === themeId);
                              return (
                                <span 
                                  key={themeId} 
                                  title={matchingTheme?.description} 
                                  className="inline-flex items-center bg-gray-50 text-gray-800 text-[10px] font-medium px-2 py-0.5 rounded-full border border-gray-200 truncate max-w-[170px]"
                                >
                                  #{themeId} {matchingTheme?.title || "Tema"}
                                </span>
                              );
                            })}
                          </div>
                        </td>

                        {/* Actions */}
                        <td className="p-4">
                          <div className="flex items-center justify-center gap-1.5">
                            {/* Manual WhatsApp Confirmation trigger */}
                            <button
                              onClick={() => handleManualWhatsAppSend(reg)}
                              title="Enviar confirmação WhatsApp"
                              className="p-1.5 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg border border-emerald-100 transition cursor-pointer"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                            </button>
                            
                            {/* Cancel Registration */}
                            <button
                              onClick={() => handleDeleteRegistration(reg.id, reg.name)}
                              title="Cancelar participante"
                              className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg border border-red-100 transition cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>

                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>

            {/* Note instruction */}
            <div className="p-4 bg-gray-50 border-t border-pool-100 text-[11px] text-gray-400 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>Dica: Clique no botão verde de conversa para simular o disparo de confirmações via WhatsApp Web usando a mensageria e variáveis.</span>
            </div>

          </div>

          {/* Quick Charts / Insights Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Top Themes Distribution */}
            <div className="bg-white p-5 rounded-2xl border border-pool-100 shadow-xs space-y-4">
              <h4 className="font-bold text-pool-950 text-sm font-display flex items-center gap-1.5">
                <BarChart3 className="w-4.5 h-4.5 text-pool-600" />
                Interesse Acumulado por Tema
              </h4>
              
              <div className="space-y-3 text-xs">
                {sortedThemesByInterest.slice(0, 5).map(theme => {
                  const count = themeCounts[theme.id] || 0;
                  const pct = totalCount > 0 ? Math.round((count / totalCount) * 100) : 0;
                  
                  return (
                    <div key={theme.id} className="space-y-1">
                      <div className="flex justify-between items-center text-[11px]">
                        <span className="font-semibold text-gray-700 truncate max-w-[210px]" title={theme.title}>
                          T{theme.id}: {theme.title}
                        </span>
                        <span className="font-mono text-pool-700 font-semibold">{count} ({pct}%)</span>
                      </div>
                      <div className="w-full bg-gray-100 rounded-full h-1.5 overflow-hidden">
                        <div 
                          className="bg-pool-500 h-1.5 rounded-full transition-all duration-500"
                          style={{ width: `${pct}%` }}
                        ></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Days & Time Metrics */}
            <div className="bg-white p-5 rounded-2xl border border-pool-100 shadow-xs space-y-4">
              <h4 className="font-bold text-pool-950 text-sm font-display flex items-center gap-1.5">
                <Calendar className="w-4.5 h-4.5 text-pool-600" />
                Demanda de Horários e Dias
              </h4>

              <div className="grid grid-cols-2 gap-4 text-xs">
                {/* Preferred Time block */}
                <div className="space-y-2">
                  <span className="font-semibold text-gray-400 text-[10px] block uppercase tracking-wider">Período Ideal</span>
                  <div className="space-y-1.5">
                    {["Manhã", "Tarde", "Noite"].map(time => {
                      const count = timeCounts[time] || 0;
                      const pct = totalCount > 0 ? Math.round((count / totalCount) * 100) : 0;
                      return (
                        <div key={time} className="flex items-center justify-between">
                          <span className="text-gray-600 font-medium">{time}</span>
                          <span className="font-mono font-semibold bg-cyan-50 border border-cyan-100 text-cyan-700 px-1.5 py-0.5 rounded text-[10px] min-w-[50px] text-center">
                            {count} ({pct}%)
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Preferred Day block */}
                <div className="space-y-2">
                  <span className="font-semibold text-gray-400 text-[10px] block uppercase tracking-wider">Dias Mais Propícios</span>
                  <div className="space-y-1.5">
                    {(Array.from(new Set(registrations.map(r => r.preferredDay))) as string[]).slice(0, 3).map(day => {
                      const count = dayCounts[day] || 0;
                      return (
                        <div key={day} className="flex items-center justify-between">
                          <span className="text-gray-600 font-medium truncate max-w-[65px]">{day}</span>
                          <span className="font-mono font-semibold bg-pool-50 border border-pool-100 text-pool-700 px-1.5 py-0.5 rounded text-[10px] text-center">
                            {count} insc.
                          </span>
                        </div>
                      );
                    })}
                    {registrations.length === 0 && <span className="text-gray-400 text-xs block italic">Aguardando cadastros</span>}
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-gray-100 flex items-center gap-1.5 text-[10px] text-gray-400">
                <Sparkles className="w-3.5 h-3.5 text-cyan-500" />
                <span>Estatísticas calculadas ao vivo a partir da base de dados local.</span>
              </div>
            </div>

          </div>

        </div>

        {/* Right Side: Integration Configurations & Simulation Settings (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Form Integrations */}
          <div className="bg-white rounded-2xl border border-pool-100 shadow-xs overflow-hidden">
            <div className="p-5 bg-gradient-to-r from-pool-600 to-pool-700 text-white">
              <h3 className="font-bold flex items-center gap-1.5 text-md font-display">
                <FileSpreadsheet className="w-5 h-5 text-pool-100" />
                Conectividade & Planilhas
              </h3>
              <p className="text-[11px] text-pool-100 mt-1">
                Envie dados automaticamente para ferramentas de gerenciamento ou planilhas externas.
              </p>
            </div>

            <form onSubmit={handleSaveSettings} className="p-5 space-y-4">
              
              {/* Google Sheets Settings section */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-gray-700 uppercase tracking-wider block">
                    Integração Google Sheets
                  </label>
                  <label className="relative inline-flex items-center cursor-pointer select-none">
                    <input 
                      type="checkbox" 
                      checked={settings.googleSheetsLinked}
                      onChange={(e) => setSettings(prev => ({ ...prev, googleSheetsLinked: e.target.checked }))}
                      className="sr-only peer" 
                    />
                    <div className="w-9 h-5 bg-gray-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500"></div>
                  </label>
                </div>

                <div className="space-y-1.5">
                  <span className="text-[11px] text-gray-400 block">
                    Vincule uma planilha online para receber as inscrições instantaneamente após o clique em "Enviar Cadastro".
                  </span>
                  <input
                    type="url"
                    disabled={!settings.googleSheetsLinked}
                    placeholder="https://docs.google.com/spreadsheets/d/..."
                    value={settings.googleSheetsUrl}
                    onChange={(e) => setSettings(prev => ({ ...prev, googleSheetsUrl: e.target.value }))}
                    className="w-full text-xs p-2.5 bg-gray-50 border border-pool-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-pool-500 disabled:opacity-50 text-gray-700 transition"
                  />
                </div>
              </div>

              {/* Custom Flyer Setting Block */}
              <div className="border-t border-gray-100 pt-4 space-y-3">
                <label className="text-xs font-bold text-gray-700 uppercase tracking-wider block">
                  Customização do Panfleto (Imagem)
                </label>
                <p className="text-[11px] text-gray-400 leading-relaxed">
                  Substitua a estrutura de código do panfleto na página inicial por uma imagem estática personalizada (como o panfleto em imagem original).
                </p>

                {settings.customFlyerBase64 ? (
                  <div className="space-y-2">
                    <div className="relative rounded-xl overflow-hidden border border-gray-200 bg-gray-50 p-1 max-w-[120px]">
                      <img 
                        src={settings.customFlyerBase64} 
                        alt="Miniatura do Panfleto" 
                        className="w-full h-auto object-contain rounded-lg"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={handleRemoveFlyer}
                      className="px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-600 text-[10px] font-bold rounded-lg transition"
                    >
                      Remover Imagem (Voltar para o site em código)
                    </button>
                  </div>
                ) : (
                  <div>
                    <label className="inline-flex items-center gap-1.5 bg-pool-50 hover:bg-pool-100 text-pool-700 text-[10px] font-bold px-3 py-2 rounded-lg cursor-pointer transition">
                      <Upload className="w-3.5 h-3.5" />
                      Fazer Upload da Imagem Original
                      <input 
                        type="file" 
                        accept="image/*" 
                        onChange={handleFlyerUpload} 
                        className="hidden" 
                      />
                    </label>
                  </div>
                )}
              </div>

              {/* Autocomplete settings */}
              <div className="border-t border-gray-100 pt-4 space-y-4">
                
                {/* Whatsapp notifications block */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-gray-700 uppercase tracking-wider block">
                      Disparo WhatsApp Automatizado
                    </label>
                    <label className="relative inline-flex items-center cursor-pointer select-none">
                      <input 
                        type="checkbox" 
                        checked={settings.whatsappAutoSend}
                        onChange={(e) => setSettings(prev => ({ ...prev, whatsappAutoSend: e.target.checked }))}
                        className="sr-only peer" 
                      />
                      <div className="w-9 h-5 bg-gray-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500"></div>
                    </label>
                  </div>
                  
                  <div className="space-y-1.5">
                    <span className="text-[11px] text-gray-400 block">
                      Define a mensagem de confirmação para os participantes. Placeholders suportados:
                    </span>
                    <div className="flex flex-wrap gap-1 text-[9px] font-mono font-semibold">
                      <span className="px-1 py-0.5 bg-pool-50 text-pool-700 rounded select-all">%NOME%</span>
                      <span className="px-1 py-0.5 bg-pool-50 text-pool-700 rounded select-all">%DIA%</span>
                      <span className="px-1 py-0.5 bg-pool-50 text-pool-700 rounded select-all">%HORARIO%</span>
                    </div>

                    <textarea
                      rows={4}
                      value={settings.whatsappTemplate}
                      onChange={(e) => setSettings(prev => ({ ...prev, whatsappTemplate: e.target.value }))}
                      className="w-full text-xs p-2.5 bg-gray-50 border border-pool-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-pool-500 text-gray-700 transition font-sans"
                      placeholder="Modelo da mensagem de confirmação para ser enviada..."
                    />
                  </div>
                </div>

              </div>

              {/* Button save settings */}
              <button
                type="submit"
                disabled={isSavingSettings}
                className="w-full py-2 bg-pool-700 hover:bg-pool-800 disabled:bg-gray-300 text-white text-xs font-semibold rounded-lg transition-all shadow-md shadow-pool-100 flex items-center justify-center gap-1"
              >
                {isSavingSettings ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    Salvando Configurações...
                  </>
                ) : (
                  <>
                    Salvar Configurações
                  </>
                )}
              </button>

              {settingsStatusMessage && (
                <div className="p-2.5 text-center bg-emerald-50 border border-emerald-100 rounded-lg text-emerald-800 text-[11px] font-semibold animate-fade-in flex items-center justify-center gap-1.5">
                  <Check className="w-3.5 h-3.5" />
                  {settingsStatusMessage}
                </div>
              )}

            </form>
          </div>

          {/* Integration Simulator Logs */}
          <div className="bg-white rounded-2xl border border-pool-100 shadow-xs p-5 space-y-4">
            <h3 className="font-bold text-pool-950 text-sm font-display flex items-center gap-1.5">
              <MessageSquare className="w-4.5 h-4.5 text-emerald-600" />
              Logs de Integração de Notificações
            </h3>
            
            <div className="space-y-3">
              {whatsappLogs.map(log => (
                <div key={log.id} className="p-3 bg-gray-50 rounded-xl border border-gray-100 space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] text-gray-400 font-mono flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {log.time}
                    </span>
                    <span className="text-[9px] bg-emerald-100 text-emerald-800 px-1 rounded font-semibold">
                      {log.status}
                    </span>
                  </div>
                  <p className="text-xs text-gray-600 font-medium font-sans">
                    {log.text}
                  </p>
                </div>
              ))}
            </div>

            <button
              onClick={() => {
                setWhatsappLogs([]);
                addWhatsappLog("Histórico de logs reiniciado.");
              }}
              className="text-[11px] text-gray-400 hover:text-red-500 font-medium transition flex items-center justify-center gap-1 cursor-pointer w-full text-center hover:underline"
            >
              Limpar Logs
            </button>
          </div>

        </div>

      </div>

    </div>
  );
}
